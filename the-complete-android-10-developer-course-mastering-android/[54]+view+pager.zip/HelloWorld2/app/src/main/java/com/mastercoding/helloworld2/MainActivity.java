package com.mastercoding.helloworld2;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;


import android.content.Context;
import android.os.Bundle;



public class MainActivity extends AppCompatActivity {

    Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);


        ViewPager viewPager = findViewById(R.id.viewPager2);

        MyPagerAdapter myPagerAdapter = new MyPagerAdapter(this);


        viewPager.setAdapter(myPagerAdapter);

    }
}